/* ============================================================
   DVDthèque — app.js
   PWA vanilla. Pas de build, pas de dépendance externe.
   Organisation :
     1. Utils & état global
     2. Store (IndexedDB) — couche données offline-first
     3. MovieAPI — abstraction de recherche film (TMDB/OMDb pluggable)
     4. Scanner — code-barres via BarcodeDetector natif
     5. AudioRecorder — commentaires audio (MediaRecorder)
     6. UI / Router / Rendu des vues
     7. Bootstrap
   ============================================================ */

'use strict';

/* ============================================================
   1. UTILS & ÉTAT GLOBAL
   ============================================================ */
const $  = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const State = {
  movies: [],          // cache mémoire de la collection
  view: 'library',
  layout: 'grid',
  sort: 'title',
  formatFilter: '',    // '' = tout, sinon 'DVD' | 'Blu-ray' | '4K'
  filters: {},         // {genre, year, format, rating}
  search: '',
  currentId: null,     // film ouvert en détail
  settings: { theme: 'dark', apiProvider: 'tmdb', apiKey: 'ff585a6b49828b724cd3c876a48cf5e0' },
};

const GENRES = ['Action','Animation','Aventure','Comédie','Crime','Documentaire',
  'Drame','Fantastique','Guerre','Histoire','Horreur','Musique','Mystère',
  'Romance','Science-Fiction','Thriller','Western'];

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

function toast(msg) {
  const t = $('#toast');
  t.textContent = msg; t.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => (t.hidden = true), 2600);
}

function fmtDuration(min) {
  if (!min) return '—';
  const h = Math.floor(min / 60), m = min % 60;
  return h ? `${h}h${String(m).padStart(2, '0')}` : `${m} min`;
}

// Formate un prix en euros (ex: 4.5 -> "4,50 €")
function fmtPrice(v) {
  if (v == null || v === '') return '';
  return Number(v).toFixed(2).replace('.', ',') + ' €';
}

/* ============================================================
   2. STORE — IndexedDB (offline-first)
   Remplace SQLite : même rôle, natif navigateur, persistant.
   Stores : "movies" (collection) et "kv" (réglages, blobs audio).
   ============================================================ */
const Store = (() => {
  const DB = 'dvdtheque', VER = 1;
  let db = null;

  function open() {
    return new Promise((res, rej) => {
      const req = indexedDB.open(DB, VER);
      req.onupgradeneeded = (e) => {
        const d = e.target.result;
        if (!d.objectStoreNames.contains('movies'))
          d.createObjectStore('movies', { keyPath: 'id' });
        if (!d.objectStoreNames.contains('kv'))
          d.createObjectStore('kv', { keyPath: 'k' });
      };
      req.onsuccess = () => { db = req.result; res(db); };
      req.onerror = () => rej(req.error);
    });
  }

  const tx = (store, mode) => db.transaction(store, mode).objectStore(store);
  const wrap = (req) => new Promise((res, rej) => {
    req.onsuccess = () => res(req.result); req.onerror = () => rej(req.error);
  });

  return {
    init: open,
    allMovies:  ()      => wrap(tx('movies', 'readonly').getAll()),
    putMovie:   (m)     => wrap(tx('movies', 'readwrite').put(m)),
    delMovie:   (id)    => wrap(tx('movies', 'readwrite').delete(id)),
    getKV:      (k)     => wrap(tx('kv', 'readonly').get(k)).then(r => r && r.v),
    setKV:      (k, v)  => wrap(tx('kv', 'readwrite').put({ k, v })),
    clearMovies:()      => wrap(tx('movies', 'readwrite').clear()),
  };
})();

/* ============================================================
   3. MOVIEAPI — abstraction de recherche film
   Implémentations interchangeables. Si pas de clé API,
   bascule sur un mode "stub" qui renvoie une fiche vierge
   pré-remplie avec le code-barres, pour saisie manuelle.
   ============================================================ */
const MovieAPI = (() => {

  // --- Provider TMDB (recherche par titre ; pas de lookup EAN natif) ---
  async function tmdbSearchByTitle(title, key) {
    const url = `https://api.themoviedb.org/3/search/movie?language=fr-FR&query=${encodeURIComponent(title)}&api_key=${key}`;
    const r = await fetch(url);
    if (!r.ok) throw new Error('TMDB ' + r.status);
    const j = await r.json();
    const hit = j.results && j.results[0];
    if (!hit) return null;
    return tmdbDetails(hit.id, key);
  }

  async function tmdbDetails(id, key) {
    const url = `https://api.themoviedb.org/3/movie/${id}?language=fr-FR&append_to_response=credits&api_key=${key}`;
    const r = await fetch(url); const j = await r.json();
    const director = (j.credits?.crew || []).find(c => c.job === 'Director');
    const cast = (j.credits?.cast || []).slice(0, 5).map(c => c.name).join(', ');
    return {
      title: j.title || '',
      originalTitle: j.original_title || '',
      year: (j.release_date || '').slice(0, 4),
      synopsis: j.overview || '',
      genre: (j.genres && j.genres[0]?.name) || '',
      director: director ? director.name : '',
      actors: cast,
      duration: j.runtime || 0,
      poster: j.poster_path ? `https://image.tmdb.org/t/p/w500${j.poster_path}` : '',
    };
  }

  // --- Provider OMDb (supporte recherche titre) ---
  async function omdbSearchByTitle(title, key) {
    const r = await fetch(`https://www.omdbapi.com/?t=${encodeURIComponent(title)}&apikey=${key}`);
    const j = await r.json();
    if (j.Response === 'False') return null;
    return {
      title: j.Title || '', originalTitle: j.Title || '',
      year: (j.Year || '').slice(0, 4), synopsis: j.Plot || '',
      genre: (j.Genre || '').split(',')[0]?.trim() || '',
      director: j.Director || '', actors: j.Actors || '',
      duration: parseInt(j.Runtime) || 0,
      poster: j.Poster && j.Poster !== 'N/A' ? j.Poster : '',
    };
  }

  /* Recherche par code-barres (EAN/UPC).
     ⚠️ Réalité : ni TMDB ni OMDb n'indexent les EAN de boîtiers DVD.
     On tente un lookup EAN via UPCitemdb à travers un proxy CORS
     (les appels directs sont bloqués depuis le navigateur). Si on
     obtient un libellé, on cherche le film par titre sur TMDB.
     À défaut, la fiche s'ouvre avec le code pré-rempli (l'utilisateur
     complète le titre, ou utilise l'OCR de la jaquette). */
  async function searchByBarcode(ean) {
    // Proxies CORS publics (on essaie dans l'ordre, ils sont parfois instables)
    const proxies = [
      (u) => `https://corsproxy.io/?url=${encodeURIComponent(u)}`,
      (u) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
    ];
    const target = `https://api.upcitemdb.com/prod/trial/lookup?upc=${ean}`;

    for (const wrap of proxies) {
      try {
        const r = await fetch(wrap(target));
        if (!r.ok) continue;
        const j = await r.json();
        const item = j.items && j.items[0];
        if (item && item.title) {
          const cleaned = item.title
            .replace(/\b(dvd|blu-?ray|4k|uhd|edition|steelbook|combo|coffret)\b/gi, '')
            .replace(/\s+/g, ' ').trim();
          const film = await searchByTitle(cleaned);
          if (film) return { ...film, barcode: ean };
          return blankFromBarcode(ean, cleaned); // titre deviné, à valider
        }
      } catch (e) { /* proxy KO, on essaie le suivant */ }
    }
    // Aucun résultat : fiche avec code pré-rempli
    return blankFromBarcode(ean, '');
  }

  async function searchByTitle(title) {
    const { apiProvider, apiKey } = State.settings;
    if (!apiKey) return null;
    try {
      return apiProvider === 'omdb'
        ? await omdbSearchByTitle(title, apiKey)
        : await tmdbSearchByTitle(title, apiKey);
    } catch (e) { console.warn('API film:', e); return null; }
  }

  /* Renvoie une LISTE de résultats TMDB (pour laisser l'utilisateur choisir
     entre "Casino" 1995 et "Casino Royale", par ex.). */
  async function searchMulti(title) {
    const { apiKey } = State.settings;
    if (!apiKey) return [];
    try {
      const url = `https://api.themoviedb.org/3/search/movie?language=fr-FR&query=${encodeURIComponent(title)}&api_key=${apiKey}`;
      const r = await fetch(url);
      if (!r.ok) return [];
      const j = await r.json();
      return (j.results || []).slice(0, 8).map(m => ({
        id: m.id,
        title: m.title || '',
        year: (m.release_date || '').slice(0, 4),
        poster: m.poster_path ? `https://image.tmdb.org/t/p/w185${m.poster_path}` : '',
      }));
    } catch (e) { console.warn('searchMulti:', e); return []; }
  }

  // Détails complets d'un film à partir de son id TMDB
  async function getDetails(id) {
    const { apiKey } = State.settings;
    try { return await tmdbDetails(id, apiKey); }
    catch (e) { console.warn('getDetails:', e); return null; }
  }

  function blankFromBarcode(ean, guessTitle) {
    return {
      title: guessTitle || '', originalTitle: '', year: '', synopsis: '',
      genre: '', director: '', actors: '', duration: 0, poster: '', barcode: ean,
    };
  }

  return { searchByBarcode, searchByTitle, searchMulti, getDetails, blankFromBarcode };
})();

/* ============================================================
   3b. CLOUD — sync Firestore (pattern ALPHABRAVO)
   - SDK Firebase compat chargé via <script> dans index.html.
   - Config en dur ci-dessous (FIREBASE_CONFIG) : remplacer les
     valeurs par celles de TON projet (console Firebase → ⚙️ →
     Paramètres → Vos applications → icône </>).
   - Auth anonyme. Stockage : users/{uid}/movies/{movieId}.
   - L'audio compressé (~16kbps, 30s, max 3/film) tient sous la
     limite Firestore de 1 Mo/document.
   - Tant que FIREBASE_CONFIG n'est pas rempli, l'app reste 100% locale.
   ============================================================ */

// ⬇️⬇️⬇️  REMPLACE CES VALEURS PAR TA CONFIG FIREBASE  ⬇️⬇️⬇️
const FIREBASE_CONFIG = {
  apiKey:            "AIzaSyAeodo3johut0aZNYzfkSmnSs8eqFf6J-U",
  authDomain:        "dvdtheque-280da.firebaseapp.com",
  projectId:         "dvdtheque-280da",
  storageBucket:     "dvdtheque-280da.firebasestorage.app",
  messagingSenderId: "620487889182",
  appId:             "1:620487889182:web:656118ca705533d642f90f",
};
// ⬆️⬆️⬆️  REMPLACE CES VALEURS PAR TA CONFIG FIREBASE  ⬆️⬆️⬆️

const Cloud = (() => {
  let db = null, auth = null, uid = null, ready = false;
  let currentUser = null;
  let onChangeCb = null;

  function configured() {
    return typeof firebase !== 'undefined'
      && FIREBASE_CONFIG.projectId
      && FIREBASE_CONFIG.projectId !== 'TON_PROJET';
  }

  function enabled() { return ready && !!uid; }
  function user() { return currentUser; }

  // Initialise Firebase et écoute l'état de connexion.
  // NE connecte PAS automatiquement : l'utilisateur clique "Se connecter".
  // onChange(user|null) est rappelé à chaque changement d'état.
  async function init(onChange) {
    if (!configured()) return false;
    if (!firebase.apps.length) firebase.initializeApp(FIREBASE_CONFIG);
    auth = firebase.auth();
    db   = firebase.firestore();
    onChangeCb = onChange;

    // Persistance locale : l'utilisateur reste connecté entre les sessions
    try { await auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL); } catch (e) {}

    auth.onAuthStateChanged((u) => {
      if (u) { currentUser = u; uid = u.uid; ready = true; }
      else   { currentUser = null; uid = null; ready = false; }
      if (onChangeCb) onChangeCb(currentUser);
    });
    return true;
  }

  // Connexion via Google (popup)
  async function signInGoogle() {
    if (!auth) return;
    const provider = new firebase.auth.GoogleAuthProvider();
    await auth.signInWithPopup(provider);
    // onAuthStateChanged se charge de la suite
  }

  async function signOut() {
    if (auth) await auth.signOut();
  }

  function moviesCol() {
    return db.collection('users').doc(uid).collection('movies');
  }

  function docTooBig(movie) {
    return new Blob([JSON.stringify(movie)]).size > 1000 * 1024;
  }

  async function pushMovie(movie) {
    if (!enabled()) return;
    if (docTooBig(movie)) {
      toast('Film trop volumineux pour la sync (trop d’audio) — gardé en local');
      return;
    }
    await moviesCol().doc(movie.id).set(movie);
  }

  async function deleteRemote(id) {
    if (!enabled()) return;
    await moviesCol().doc(id).delete();
  }

  async function pullAll() {
    if (!enabled()) return [];
    const snap = await moviesCol().get();
    const out = [];
    snap.forEach((d) => out.push(d.data()));
    return out;
  }

  async function pushAll(movies) {
    if (!enabled()) return;
    for (const m of movies) {
      if (!docTooBig(m)) await moviesCol().doc(m.id).set(m);
    }
  }

  return { init, configured, enabled, user, signInGoogle, signOut,
           pushMovie, deleteRemote, pullAll, pushAll, uid: () => uid };
})();

/* ============================================================
   4. SCANNER — code-barres, double moteur
   - BarcodeDetector natif si présent (Chrome/Android) : rapide.
   - Sinon ZXing-wasm (iOS Safari, Firefox…) : décodage WASM
     d'une frame vidéo capturée sur <canvas>.
   Même résultat dans les deux cas : un EAN passé à onResult.

   ZXing v3 (IIFE global "ZXingWASM") est chargé à la demande
   depuis jsDelivr ; le binaire .wasm est pointé vers le CDN via
   prepareZXingModule. Cf. index.html (balise <script> + dépôt offline possible).
   ============================================================ */
const Scanner = (() => {
  const ZXING_VER = '3.0.3';
  const ZXING_IIFE = `https://cdn.jsdelivr.net/npm/zxing-wasm@${ZXING_VER}/dist/iife/reader/index.js`;
  const ZXING_WASM = `https://cdn.jsdelivr.net/npm/zxing-wasm@${ZXING_VER}/dist/reader/zxing_reader.wasm`;
  const FORMATS_NATIVE = ['ean_13', 'ean_8', 'upc_a', 'upc_e'];
  const FORMATS_ZXING  = ['EAN-13', 'EAN-8', 'UPC-A', 'UPC-E'];
  const ZXING_THROTTLE = 220; // ms entre deux décodages WASM

  let stream = null, raf = null, detector = null, onResult = null;
  let mode = null;            // 'native' | 'zxing'
  let canvas = null, ctx = null, lastDecode = 0, zxingReady = false, decoding = false;

  // Charge le script IIFE ZXing une seule fois et configure le chemin du .wasm
  function loadZXing() {
    if (window.ZXingWASM) return Promise.resolve();
    return new Promise((res, rej) => {
      const s = document.createElement('script');
      s.src = ZXING_IIFE;
      s.onload = () => {
        try {
          // Pointe le binaire wasm vers le CDN (sinon ZXing le cherche en relatif)
          window.ZXingWASM.prepareZXingModule({
            overrides: {
              locateFile: (path, prefix) =>
                path.endsWith('.wasm') ? ZXING_WASM : (prefix + path),
            },
          });
        } catch (e) { /* prepareZXingModule absente sur très vieilles versions */ }
        res();
      };
      s.onerror = () => rej(new Error('Chargement ZXing impossible (réseau ?)'));
      document.head.appendChild(s);
    });
  }

  async function start(cb) {
    onResult = cb;
    const modal = $('#scanner-modal'), video = $('#scanner-video'), hint = $('#scanner-hint');
    modal.hidden = false;
    hint.textContent = 'Initialisation de la caméra…';

    // 1. Ouvrir la caméra (geste utilisateur requis sur iOS — OK, déclenché par tap)
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false,
      });
      video.srcObject = stream;
      video.setAttribute('playsinline', ''); // indispensable iOS
      await video.play();
    } catch (e) {
      hint.textContent = 'Caméra indisponible : ' + (e.message || e.name || '');
      console.warn(e);
      return;
    }

    // 2. Choisir le moteur
    if ('BarcodeDetector' in window) {
      try {
        detector = new BarcodeDetector({ formats: FORMATS_NATIVE });
        mode = 'native';
      } catch (e) { mode = null; }
    }
    if (mode !== 'native') {
      hint.textContent = 'Chargement du moteur de scan…';
      try {
        await loadZXing();
        mode = 'zxing';
        zxingReady = true;
        canvas = document.createElement('canvas');
        ctx = canvas.getContext('2d', { willReadFrequently: true });
      } catch (e) {
        hint.textContent = "Scan auto indisponible. Saisie manuelle…";
        console.warn(e);
        setTimeout(() => { stop(); openEditor(MovieAPI.blankFromBarcode('', '')); }, 1600);
        return;
      }
    }

    hint.textContent = 'Visez le code-barres au dos du boîtier';
    loop(video);
  }

  function loop(video) {
    if (!mode) return;
    if (mode === 'native') decodeNative(video);
    else decodeZXing(video);
    raf = requestAnimationFrame(() => loop(video));
  }

  async function decodeNative(video) {
    if (decoding) return;
    decoding = true;
    try {
      const codes = await detector.detect(video);
      if (codes && codes.length) return finish(codes[0].rawValue);
    } catch (e) { /* frame non décodable */ }
    decoding = false;
  }

  async function decodeZXing(video) {
    const now = performance.now();
    if (decoding || !zxingReady || (now - lastDecode) < ZXING_THROTTLE) return;
    if (!video.videoWidth) return;
    decoding = true; lastDecode = now;
    try {
      // Capture la frame courante. On réduit la résolution pour la vitesse.
      const scale = Math.min(1, 1000 / video.videoWidth);
      canvas.width  = Math.round(video.videoWidth  * scale);
      canvas.height = Math.round(video.videoHeight * scale);
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const results = await window.ZXingWASM.readBarcodes(imgData, {
        tryHarder: true,
        formats: FORMATS_ZXING,
        maxNumberOfSymbols: 1, // v3
        maxSymbols: 1,         // v1/v2 (clé ignorée si inconnue)
      });
      if (results && results.length && results[0].text) {
        return finish(results[0].text);
      }
    } catch (e) { /* décodage raté sur cette frame, on continue */ }
    decoding = false;
  }

  function finish(ean) {
    if (navigator.vibrate) navigator.vibrate(80);
    const cb = onResult;
    stop();
    cb && cb(ean);
  }

  function stop() {
    $('#scanner-modal').hidden = true;
    if (raf) { cancelAnimationFrame(raf); raf = null; }
    if (stream) { stream.getTracks().forEach(t => t.stop()); stream = null; }
    detector = null; mode = null; decoding = false;
  }

  return { start, stop };
})();

/* ============================================================
   5. AUDIORECORDER — commentaires audio (MediaRecorder)
   Stocke un Blob audio compressé (Opus ~16 kbps) pour rester
   compatible avec la sync Firestore (limite 1 Mo / document).
   - Bitrate volontairement bas : voix intelligible, ~78 Ko/30s en base64.
   - Durée plafonnée (auto-stop) pour borner la taille.
   ⚠️ iOS Safari : MediaRecorder supporté sur iOS récents ; on
   détecte et on prévient si indisponible.
   ============================================================ */
const AudioRecorder = (() => {
  const MAX_SEC = 30;             // durée max par enregistrement
  const BITRATE = 16000;          // 16 kbps — voix
  const MAX_PER_MOVIE = 3;        // nb max de commentaires audio par film

  let rec = null, chunks = [], stream = null, startTs = 0, autoStop = null, onAuto = null;

  function supported() { return 'MediaRecorder' in window && navigator.mediaDevices; }

  // cb appelé si l'auto-stop se déclenche (pour mettre à jour l'UI)
  async function start(onAutoStop) {
    if (!supported()) throw new Error('Enregistrement audio non supporté sur ce navigateur.');
    onAuto = onAutoStop;
    stream = await navigator.mediaDevices.getUserMedia({
      audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true },
    });
    chunks = [];
    const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus'
      : MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm'
      : MediaRecorder.isTypeSupported('audio/mp4') ? 'audio/mp4' : '';
    const opts = { audioBitsPerSecond: BITRATE };
    if (mime) opts.mimeType = mime;
    rec = new MediaRecorder(stream, opts);
    rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
    rec.start();
    startTs = Date.now();
    // Auto-stop à MAX_SEC
    autoStop = setTimeout(() => { onAuto && onAuto(); }, MAX_SEC * 1000);
  }

  function stop() {
    return new Promise((res) => {
      if (autoStop) { clearTimeout(autoStop); autoStop = null; }
      if (!rec) return res(null);
      rec.onstop = () => {
        const blob = new Blob(chunks, { type: (rec && rec.mimeType) || 'audio/webm' });
        const dur = Math.min(MAX_SEC, Math.round((Date.now() - startTs) / 1000));
        stream.getTracks().forEach(t => t.stop());
        rec = null; stream = null;
        res({ blob, dur });
      };
      rec.stop();
    });
  }

  // Blob -> base64 (pour stockage IndexedDB sérialisable et sync Firestore)
  const blobToB64 = (blob) => new Promise((res) => {
    const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(blob);
  });

  return { supported, start, stop, blobToB64, MAX_SEC, MAX_PER_MOVIE };
})();

/* ============================================================
   5b. OCR — reconnaissance du titre sur jaquette (Tesseract.js)
   Chargé à la demande depuis jsDelivr (v5, global "Tesseract").
   Renvoie une liste de lignes candidates triées par taille de
   texte (les plus grosses = plus probablement le titre).
   L'utilisateur choisit/corrige avant la recherche TMDB.
   ============================================================ */
const OCR = (() => {
  const TESS_VER = '5';
  const TESS_SRC = `https://cdn.jsdelivr.net/npm/tesseract.js@${TESS_VER}/dist/tesseract.min.js`;
  let worker = null;

  function loadLib() {
    if (window.Tesseract) return Promise.resolve();
    return new Promise((res, rej) => {
      const s = document.createElement('script');
      s.src = TESS_SRC;
      s.onload = res;
      s.onerror = () => rej(new Error('Chargement Tesseract impossible (réseau ?)'));
      document.head.appendChild(s);
    });
  }

  /* Pré-traitement : charge l'image, l'agrandit si trop petite, passe en
     niveaux de gris avec contraste accentué (seuil adaptatif simple).
     C'est CE traitement qui améliore le plus la lecture d'un titre.
     Renvoie un canvas prêt pour Tesseract. */
  function preprocess(dataURL) {
    return new Promise((res, rej) => {
      const img = new Image();
      img.onload = () => {
        // Cible ~1600px de large pour que le texte soit assez gros
        const targetW = 1600;
        const scale = img.width < targetW ? targetW / img.width : 1;
        const w = Math.round(img.width * scale);
        const h = Math.round(img.height * scale);
        const canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);

        // Niveaux de gris + contraste + binarisation douce
        const imgData = ctx.getImageData(0, 0, w, h);
        const d = imgData.data;
        // 1er passage : moyenne de luminance pour le seuil
        let sum = 0;
        for (let i = 0; i < d.length; i += 4) {
          const g = 0.299*d[i] + 0.587*d[i+1] + 0.114*d[i+2];
          sum += g;
        }
        const mean = sum / (d.length / 4);
        // 2e passage : contraste fort autour de la moyenne
        const contrast = 1.4;
        for (let i = 0; i < d.length; i += 4) {
          let g = 0.299*d[i] + 0.587*d[i+1] + 0.114*d[i+2];
          g = (g - mean) * contrast + mean;       // étire le contraste
          g = Math.max(0, Math.min(255, g));
          d[i] = d[i+1] = d[i+2] = g;             // gris
        }
        ctx.putImageData(imgData, 0, 0);
        res(canvas);
      };
      img.onerror = () => rej(new Error('Image illisible'));
      img.src = dataURL;
    });
  }

  // image = dataURL ; onProgress = callback(0..1)
  // URL de la Cloud Function Google Vision (déployée par l'utilisateur)
  const CLOUD_OCR_URL = 'https://europe-west1-dvdtheque-280da.cloudfunctions.net/ocr';

  // OCR via Google Cloud Vision (bien meilleur que Tesseract).
  // Renvoie le même format { candidates, rawText } ou lève une erreur.
  async function recognizeCloud(dataURL, onProgress) {
    if (onProgress) onProgress(0.3); // pas de vraie progression côté serveur
    const r = await fetch(CLOUD_OCR_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ image: dataURL }),
    });
    if (onProgress) onProgress(0.9);
    if (!r.ok) throw new Error('Cloud OCR HTTP ' + r.status);
    const j = await r.json();
    if (j.error) throw new Error(j.error);
    const lines = (j.lines || []).filter(t =>
      t.length >= 2 &&
      !/^(dvd|blu-?ray|4k|uhd|tous droits|all rights|©|warner|universal|sony|paramount|fox|disney)/i.test(t)
    );
    if (onProgress) onProgress(1);
    return { candidates: lines.slice(0, 8), rawText: j.fullText || '' };
  }

  async function recognize(dataURL, onProgress) {
    // 1) On tente Google Cloud Vision (qualité nettement supérieure)
    try {
      const cloud = await recognizeCloud(dataURL, onProgress);
      if (cloud.candidates.length) return cloud;
      // Vision a répondu mais rien trouvé → on tente quand même Tesseract
    } catch (e) {
      console.warn('Cloud Vision indisponible, repli Tesseract:', e);
    }

    // 2) Repli : Tesseract local
    await loadLib();
    if (!worker) {
      worker = await window.Tesseract.createWorker('fra+eng', 1, {
        logger: (m) => {
          if (m.status === 'recognizing text' && onProgress) onProgress(m.progress);
        },
      });
    }
    try {
      await worker.setParameters({
        tessedit_pageseg_mode: '6',
        preserve_interword_spaces: '1',
      });
    } catch (e) { /* selon version */ }

    const canvas = await preprocess(dataURL);
    const { data } = await worker.recognize(canvas);
    return extractCandidates(data);
  }

  // Trie les lignes par taille de texte (titre = gros) × confiance.
  function extractCandidates(data) {
    const lines = (data.lines || [])
      .map(l => {
        const bbox = l.bbox || {};
        const h = (bbox.y1 || 0) - (bbox.y0 || 0);
        const text = (l.text || '').replace(/\s+/g, ' ').trim();
        return { text, h, conf: l.confidence || 0 };
      })
      .filter(l => l.text.length >= 2 && /[a-zA-ZÀ-ÿ0-9]/.test(l.text))
      .filter(l => !/^(dvd|blu-?ray|4k|uhd|tous droits|all rights|©|warner|universal|sony|paramount|fox|disney)/i.test(l.text))
      .filter(l => l.conf > 30); // ignore le texte trop incertain

    lines.sort((a, b) => (b.h * (b.conf / 100 + 0.5)) - (a.h * (a.conf / 100 + 0.5)));
    const seen = new Set(), out = [];
    for (const l of lines) {
      const k = l.text.toLowerCase();
      if (seen.has(k)) continue;
      seen.add(k); out.push(l.text);
      if (out.length >= 6) break;
    }
    return { candidates: out, rawText: (data.text || '').trim() };
  }

  async function terminate() {
    if (worker) { await worker.terminate(); worker = null; }
  }

  return { recognize, terminate };
})();

/* ============================================================
   6. UI / ROUTER / RENDU
   ============================================================ */

/* ---- Navigation entre vues ---- */
function go(view, opts = {}) {
  State.view = view;
  $$('.view').forEach(v => (v.hidden = v.dataset.view !== view));
  $$('.tab[data-go]').forEach(t => t.classList.toggle('active', t.dataset.go === view));

  const titles = { library: 'DVDthèque', wishlist: 'Wishlist', random: 'Aléatoire', profile: 'Profil', detail: '' };
  $('#topbar-title').textContent = opts.title || titles[view] || '';
  $('#back-btn').hidden = view !== 'detail';
  $('#search-toggle').hidden = view !== 'library';
  if (view !== 'library') { $('#searchbar').hidden = true; }

  if (view === 'library') renderLibrary();
  if (view === 'wishlist') renderWishlist();
  if (view === 'random') renderRandomView();
  if (view === 'profile') renderProfile();
  $('#views').scrollTop = 0;
}

/* ---- Filtre + tri appliqués à la collection ---- */
function visibleMovies() {
  let list = State.movies.filter(m => !m.wishlist); // biblio = hors wishlist
  const f = State.filters, s = State.search.toLowerCase().trim();

  // Filtre maître par format (Tout / DVD / Blu-ray / 4K)
  if (State.formatFilter) list = list.filter(m => (m.format || 'DVD') === State.formatFilter);

  if (s) list = list.filter(m =>
    (m.title || '').toLowerCase().includes(s) ||
    (m.director || '').toLowerCase().includes(s) ||
    (m.actors || '').toLowerCase().includes(s));
  if (f.genre)  list = list.filter(m => m.genre === f.genre);
  if (f.year)   list = list.filter(m => String(m.year) === String(f.year));
  if (f.format) list = list.filter(m => m.format === f.format);
  if (f.rating) list = list.filter(m => (m.rating || 0) >= f.rating);

  const by = State.sort;
  list.sort((a, b) => {
    switch (by) {
      case 'title':       return (a.title||'').localeCompare(b.title||'');
      case 'title_desc':  return (b.title||'').localeCompare(a.title||'');
      case 'year':        return (a.year||0) - (b.year||0);
      case 'year_desc':   return (b.year||0) - (a.year||0);
      case 'rating_desc': return (b.rating||0) - (a.rating||0);
      case 'added_desc':  return (b.addedAt||0) - (a.addedAt||0);
      default: return 0;
    }
  });
  return list;
}

/* ---- Rendu bibliothèque ---- */
function renderLibrary() {
  const grid = $('#library-grid');
  const list = visibleMovies();
  $('#library-empty').hidden = list.length !== 0;
  grid.className = 'grid' + (State.layout === 'list' ? ' list' : '');

  grid.innerHTML = list.map(m => {
    const poster = m.poster
      ? `style="background-image:url('${m.poster.replace(/'/g, "%27")}')"` : '';
    const initial = (m.title || '?').charAt(0).toUpperCase();
    const priceTxt = (m.price != null && m.price !== '') ? fmtPrice(m.price) : '';
    if (State.layout === 'list') {
      return `<div class="card" data-id="${m.id}">
        <div class="poster-wrap"><div class="poster" ${poster}>${m.poster ? '' : initial}</div></div>
        <div class="meta">
          <div class="t">${esc(m.title)}</div>
          <div class="sub">${m.year || '—'} · ${esc(m.genre || '')} · ${m.format || 'DVD'}${priceTxt ? ' · <span class="price-inline">' + priceTxt + '</span>' : ''}</div>
          <div class="sub">${'★'.repeat(m.rating||0)}${'☆'.repeat(5-(m.rating||0))}</div>
        </div></div>`;
    }
    return `<div class="card" data-id="${m.id}">
      <div class="poster-wrap">
        <div class="poster" ${poster}>${m.poster ? '' : initial}</div>
        <span class="fmt-badge">${m.format || 'DVD'}</span>
      </div>
      <div class="meta"><div class="t">${esc(m.title)}</div><div class="y">${m.year || ''}${priceTxt ? ' <span class="price-inline">' + priceTxt + '</span>' : ''}</div></div>
    </div>`;
  }).join('');

  $$('.card', grid).forEach(c =>
    c.addEventListener('click', () => openDetail(c.dataset.id)));

  // Récapitulatif en bas : nombre de films (toujours) + valeur (si prix renseignés)
  const totalBox = $('#library-total');
  const withPrice = list.filter(m => m.price != null && m.price !== '');
  if (list.length) {
    const nb = `<b>${list.length}</b> film${list.length > 1 ? 's' : ''}`;
    let html = nb;
    if (withPrice.length) {
      const total = withPrice.reduce((s, m) => s + Number(m.price), 0);
      html += ` · Valeur : <b>${fmtPrice(total)}</b>`;
      if (withPrice.length < list.length) {
        html += ` <span class="muted small">(${withPrice.length}/${list.length} avec prix)</span>`;
      }
    }
    totalBox.innerHTML = html;
    totalBox.hidden = false;
  } else {
    totalBox.hidden = true;
  }

  renderActiveFilters();
}

/* Rendu de la wishlist (films souhaités, champ wishlist=true) */
function renderWishlist() {
  const grid = $('#wishlist-grid');
  const list = State.movies.filter(m => m.wishlist);
  $('#wishlist-empty').hidden = list.length !== 0;
  grid.className = 'grid';
  grid.innerHTML = list.map(m => {
    const poster = m.poster
      ? `style="background-image:url('${m.poster.replace(/'/g, "%27")}')"` : '';
    const initial = (m.title || '?').charAt(0).toUpperCase();
    return `<div class="card" data-id="${m.id}">
      <div class="poster-wrap">
        <div class="poster" ${poster}>${m.poster ? '' : initial}</div>
        <span class="fmt-badge wish">♡ ${m.format || 'DVD'}</span>
      </div>
      <div class="meta"><div class="t">${esc(m.title)}</div><div class="y">${m.year || ''}</div></div>
    </div>`;
  }).join('');
  $$('.card', grid).forEach(c =>
    c.addEventListener('click', () => openDetail(c.dataset.id)));
}

function renderActiveFilters() {
  const box = $('#active-filters'); const f = State.filters;
  const chips = [];
  if (f.genre)  chips.push(['Genre', f.genre, 'genre']);
  if (f.year)   chips.push(['Année', f.year, 'year']);
  if (f.format) chips.push(['Format', f.format, 'format']);
  if (f.rating) chips.push(['Note', '★' + f.rating + '+', 'rating']);
  box.innerHTML = chips.map(([k, v, key]) =>
    `<span class="chip"><b>${k}:</b> ${esc(String(v))} <span class="x" data-key="${key}">✕</span></span>`).join('');
  $$('.chip .x', box).forEach(x => x.addEventListener('click', () => {
    delete State.filters[x.dataset.key]; renderLibrary();
  }));
}

const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/* ---- Détail film ---- */
function openDetail(id) {
  const m = State.movies.find(x => x.id === id);
  if (!m) return;
  State.currentId = id;
  go('detail', { title: m.title });
  renderDetail(m);
}

function renderDetail(m) {
  const c = $('#detail-content');
  const hero = m.poster ? `style="background-image:url('${m.poster}')"` : '';
  c.innerHTML = `
    <div class="detail-hero" ${hero}>
      <div class="detail-poster" style="${m.poster ? `background-image:url('${m.poster}')` : ''}"></div>
      <div class="detail-headline">
        <h2>${esc(m.title)}</h2>
        ${m.originalTitle && m.originalTitle !== m.title ? `<div class="orig">${esc(m.originalTitle)}</div>` : ''}
        <div class="facts">${[m.year, m.genre, fmtDuration(m.duration), m.format].filter(Boolean).join(' · ')}</div>
      </div>
    </div>

    <div class="detail-section">
      <h4>Ma note</h4>
      <div class="rating-stars" id="rating-edit">${[1,2,3,4,5].map(i =>
        `<span data-v="${i}" class="${i <= (m.rating||0) ? 'on' : ''}">★</span>`).join('')}</div>
    </div>

    ${m.synopsis ? `<div class="detail-section"><h4>Synopsis</h4><p>${esc(m.synopsis)}</p></div>` : ''}

    <div class="detail-section">
      <h4>Fiche technique</h4>
      <div class="info-grid">
        <div><div class="lbl">Réalisateur</div><div class="val">${esc(m.director) || '—'}</div></div>
        <div><div class="lbl">Acteurs</div><div class="val">${esc(m.actors) || '—'}</div></div>
        <div><div class="lbl">Durée</div><div class="val">${fmtDuration(m.duration)}</div></div>
        <div><div class="lbl">Prix d'achat</div><div class="val">${m.price != null && m.price !== '' ? fmtPrice(m.price) : '—'}</div></div>
        <div><div class="lbl">Code-barres</div><div class="val">${m.barcode || '—'}</div></div>
      </div>
    </div>

    <div class="detail-section">
      <h4>Commentaires audio</h4>
      <div class="audio-list" id="audio-list"></div>
      <button class="rec-btn" id="rec-btn" style="margin-top:8px"><span>🎙️</span> Enregistrer un commentaire</button>
    </div>

    <div class="detail-section">
      <h4>Commentaire texte</h4>
      <div id="text-comments"></div>
      <div class="field" style="margin-top:8px">
        <textarea id="new-comment" placeholder="Votre avis sur ce film…"></textarea>
      </div>
      <button class="btn-secondary" id="add-text-comment" style="width:100%">Ajouter le commentaire</button>
      ${m.wishlist ? `<button class="btn-primary" id="detail-found" style="width:100%;margin-top:10px">✅ J'ai trouvé ce film → l'ajouter à ma collection</button>` : ''}
    </div>

    <div class="detail-actions">
      <button class="btn-secondary" id="detail-edit">Modifier</button>
      <button class="btn-secondary" id="detail-share">Partager</button>
      <button class="btn-secondary" id="detail-delete" style="color:var(--accent)">Supprimer</button>
    </div>
  `;

  // Note
  $$('#rating-edit span').forEach(s => s.addEventListener('click', async () => {
    m.rating = +s.dataset.v; await Store.putMovie(m);
    if (Cloud.enabled()) Cloud.pushMovie(m).catch(() => {});
    renderDetail(m);
  }));
  // Audio
  renderAudioList(m);
  $('#rec-btn').addEventListener('click', () => toggleRecording(m));
  // Texte
  renderTextComments(m);
  $('#add-text-comment').addEventListener('click', async () => {
    const v = $('#new-comment').value.trim(); if (!v) return;
    m.textComments = m.textComments || [];
    m.textComments.push({ id: uid(), text: v, at: Date.now() });
    await Store.putMovie(m);
    if (Cloud.enabled()) Cloud.pushMovie(m).catch(() => {});
    renderDetail(m);
  });
  // Actions
  const foundBtn = $('#detail-found');
  if (foundBtn) foundBtn.addEventListener('click', async () => {
    m.wishlist = false;            // passe de la wishlist à la collection
    m.addedAt = Date.now();        // daté comme un nouvel ajout
    await Store.putMovie(m);
    if (Cloud.enabled()) Cloud.pushMovie(m).catch(() => {});
    toast('Ajouté à votre collection ✅');
    go('library');
  });
  $('#detail-edit').addEventListener('click', () => openEditor(m, true));
  $('#detail-share').addEventListener('click', () => shareMovie(m));
  $('#detail-delete').addEventListener('click', async () => {
    const lieu = m.wishlist ? 'la wishlist' : 'la collection';
    if (!confirm(`Supprimer ce film de ${lieu} ?`)) return;
    await Store.delMovie(m.id);
    if (Cloud.enabled()) Cloud.deleteRemote(m.id).catch(() => {});
    State.movies = State.movies.filter(x => x.id !== m.id);
    toast('Film supprimé'); go(m.wishlist ? 'wishlist' : 'library');
  });
}

function renderTextComments(m) {
  const box = $('#text-comments');
  const list = m.textComments || [];
  box.innerHTML = list.map(c => `<div class="text-comment">${esc(c.text)}
    <div class="when">${new Date(c.at).toLocaleDateString('fr-FR')}</div></div>`).join('');
}

/* ---- Audio : rendu + record ---- */
function renderAudioList(m) {
  const box = $('#audio-list');
  const list = m.audio || [];
  if (!list.length) { box.innerHTML = `<p class="muted small">Aucun commentaire audio.</p>`; return; }
  box.innerHTML = list.map(a => `<div class="audio-item" data-id="${a.id}">
    <span class="play">▶</span>
    <span class="label">Commentaire audio</span>
    <span class="dur">${a.dur || 0}s</span>
    <span class="del">🗑</span>
  </div>`).join('');
  $$('.audio-item', box).forEach(item => {
    const a = list.find(x => x.id === item.dataset.id);
    item.querySelector('.play').addEventListener('click', () => {
      const audio = new Audio(a.data); audio.play();
    });
    item.querySelector('.del').addEventListener('click', async () => {
      m.audio = m.audio.filter(x => x.id !== a.id);
      await Store.putMovie(m); renderDetail(m);
    });
  });
}

let recording = false;
let recCountdown = null;
async function toggleRecording(m) {
  const btn = $('#rec-btn');

  if (!recording) {
    // Garde-fou : nombre max de commentaires audio par film
    if ((m.audio || []).length >= AudioRecorder.MAX_PER_MOVIE) {
      toast(`Maximum ${AudioRecorder.MAX_PER_MOVIE} commentaires audio par film`);
      return;
    }
    try {
      // L'auto-stop (durée max) réutilise le même chemin que l'arrêt manuel
      await AudioRecorder.start(() => { if (recording) toggleRecording(m); });
      recording = true;
      btn.classList.add('recording');
      let left = AudioRecorder.MAX_SEC;
      const paint = () => { btn.innerHTML = `<span class="rec-dot"></span> Arrêter (${left}s)`; };
      paint();
      recCountdown = setInterval(() => { left--; if (left >= 0) paint(); }, 1000);
    } catch (e) { toast(e.message); }
  } else {
    if (recCountdown) { clearInterval(recCountdown); recCountdown = null; }
    const out = await AudioRecorder.stop();
    recording = false;
    if (out) {
      const b64 = await AudioRecorder.blobToB64(out.blob);
      m.audio = m.audio || [];
      m.audio.push({ id: uid(), data: b64, dur: out.dur, at: Date.now() });
      await Store.putMovie(m);
      if (Cloud.enabled()) Cloud.pushMovie(m).catch(() => {});
    }
    renderDetail(m);
  }
}

/* ---- Aléatoire ---- */
function renderRandomView() {
  const gsel = $('#random-genre');
  gsel.innerHTML = '<option value="">Tous genres</option>' +
    [...new Set(State.movies.map(m => m.genre).filter(Boolean))].sort()
      .map(g => `<option>${esc(g)}</option>`).join('');
}

let randomPick = null;
function spinRandom() {
  const genre = $('#random-genre').value;
  const minR = +$('#random-rating').value;
  let pool = State.movies.filter(m =>
    !m.wishlist &&
    (!State.formatFilter || (m.format || 'DVD') === State.formatFilter) &&
    (!genre || m.genre === genre) && (m.rating || 0) >= minR);
  if (!pool.length) { toast('Aucun film ne correspond'); return; }

  const reel = $('#random-reel');
  reel.classList.add('spinning');
  $('#random-open').hidden = true;
  let ticks = 0;
  const iv = setInterval(() => {
    const r = pool[Math.floor(Math.random() * pool.length)];
    reel.innerHTML = r.poster
      ? `<div class="poster" style="background-image:url('${r.poster}')"></div>`
      : `<div class="reel-placeholder">${esc((r.title||'?')[0])}</div>`;
    if (++ticks > 14) {
      clearInterval(iv);
      reel.classList.remove('spinning');
      randomPick = pool[Math.floor(Math.random() * pool.length)];
      reel.innerHTML = randomPick.poster
        ? `<div class="poster" style="background-image:url('${randomPick.poster}')"></div>`
        : `<div class="reel-placeholder">${esc(randomPick.title)}</div>`;
      $('#random-open').hidden = false;
    }
  }, 90);
}

/* ---- Profil ---- */
function renderProfile() {
  $('#profile-meta').textContent = `${State.movies.length} film${State.movies.length > 1 ? 's' : ''} dans la collection`;
  $('#set-theme').textContent = 'Thème : ' + (State.settings.theme === 'dark' ? 'Sombre' : 'Clair');

  const u = Cloud.user && Cloud.user();
  const nameEl = $('#profile-name'), avatarEl = $('#profile-avatar'), cloudBtn = $('#set-cloud');
  if (u) {
    nameEl.textContent = u.displayName || u.email || 'Connecté';
    if (u.photoURL) {
      avatarEl.style.backgroundImage = `url('${u.photoURL}')`;
      avatarEl.textContent = '';
    } else {
      avatarEl.style.backgroundImage = '';
      avatarEl.textContent = (u.displayName || u.email || '?').charAt(0).toUpperCase();
    }
    if (cloudBtn) cloudBtn.textContent = 'Se déconnecter';
  } else {
    nameEl.textContent = 'Invité';
    avatarEl.style.backgroundImage = '';
    avatarEl.textContent = '?';
    if (cloudBtn) cloudBtn.textContent = 'Se connecter avec Google';
  }
}

/* ---- Éditeur de fiche (ajout/modif manuels) ---- */
function openEditor(data, isEdit = false, onDone = null) {
  closeSheet();
  const m = isEdit ? data : {
    id: uid(), addedAt: Date.now(), format: 'DVD', rating: 0,
    audio: [], textComments: [], ...data,
  };

  $('#edit-title-h').textContent = isEdit ? 'Modifier' : 'Nouveau film';
  $('#edit-form').innerHTML = `
    <button class="btn-primary" id="tmdb-fill" style="margin-bottom:16px">🔍 Remplir automatiquement depuis TMDB</button>
    <div class="field"><label>Ajouter à</label><select id="f-dest">
      <option value="library" ${!m.wishlist ? 'selected' : ''}>Ma collection</option>
      <option value="wishlist" ${m.wishlist ? 'selected' : ''}>Wishlist (à trouver)</option>
    </select></div>
    ${field('title', 'Titre', m.title)}
    ${field('originalTitle', 'Titre original', m.originalTitle)}
    <div class="field"><label>Format</label><select id="f-format">
      ${['DVD','Blu-ray','4K'].map(o => `<option ${m.format===o?'selected':''}>${o}</option>`).join('')}
    </select></div>
    ${field('year', 'Année', m.year, 'number')}
    <div class="field"><label>Genre</label><select id="f-genre">
      <option value="">—</option>
      ${GENRES.map(g => `<option ${m.genre===g?'selected':''}>${g}</option>`).join('')}
    </select></div>
    ${field('director', 'Réalisateur', m.director)}
    ${field('actors', 'Acteurs', m.actors)}
    ${field('duration', 'Durée (min)', m.duration, 'number')}
    ${field('price', "Prix d'achat (€)", m.price, 'number')}
    ${field('poster', 'URL jaquette', m.poster)}
    <div id="poster-preview"></div>
    <div class="field"><label>Synopsis</label><textarea id="f-synopsis">${esc(m.synopsis||'')}</textarea></div>
    ${field('barcode', 'Code-barres', m.barcode)}
  `;
  $('#edit-modal').hidden = false;
  $('#edit-backdrop').hidden = false;
  renderPosterPreview(m.poster);

  // Recherche TMDB à partir du titre saisi → remplit tous les champs + jaquette.
  // Messages d'erreur affichés à l'écran (pas besoin de la console).
  $('#tmdb-fill').onclick = async () => {
    const title = $('#f-title').value.trim();
    if (!title) { toast('Saisis d’abord un titre'); return; }
    toast('Recherche TMDB : ' + title + '…');
    try {
      const key = State.settings.apiKey;
      const url = `https://api.themoviedb.org/3/search/movie?language=fr-FR&query=${encodeURIComponent(title)}&api_key=${key}`;
      const r = await fetch(url);
      if (!r.ok) { alert('TMDB erreur HTTP ' + r.status + ' (clé invalide ?)'); return; }
      const j = await r.json();
      if (!j.results || !j.results.length) { alert('Aucun film trouvé pour « ' + title +' ».'); return; }
      const id = j.results[0].id;
      const dr = await fetch(`https://api.themoviedb.org/3/movie/${id}?language=fr-FR&append_to_response=credits&api_key=${key}`);
      const d = await dr.json();
      const director = (d.credits?.crew || []).find(c => c.job === 'Director');
      const cast = (d.credits?.cast || []).slice(0, 5).map(c => c.name).join(', ');
      $('#f-title').value         = d.title || title;
      $('#f-originalTitle').value = d.original_title || '';
      $('#f-year').value          = (d.release_date || '').slice(0, 4);
      $('#f-director').value      = director ? director.name : '';
      $('#f-actors').value        = cast;
      $('#f-duration').value      = d.runtime || '';
      $('#f-poster').value        = d.poster_path ? `https://image.tmdb.org/t/p/w500${d.poster_path}` : '';
      $('#f-synopsis').value      = d.overview || '';
      if (d.genres && d.genres[0]) {
        const opt = [...$('#f-genre').options].find(o => o.value.toLowerCase() === d.genres[0].name.toLowerCase());
        if (opt) $('#f-genre').value = opt.value;
      }
      renderPosterPreview($('#f-poster').value);
      toast('Champs remplis ✅');
    } catch (e) {
      alert('Erreur réseau TMDB : ' + (e.message || e));
    }
  };

  $('#edit-save').onclick = async () => {
    m.title         = $('#f-title').value.trim() || 'Sans titre';
    m.originalTitle = $('#f-originalTitle').value.trim();
    m.format        = $('#f-format').value;
    m.year          = $('#f-year').value;
    m.genre         = $('#f-genre').value;
    m.director      = $('#f-director').value.trim();
    m.actors        = $('#f-actors').value.trim();
    m.duration      = +$('#f-duration').value || 0;
    m.poster        = $('#f-poster').value.trim();
    m.synopsis      = $('#f-synopsis').value.trim();
    m.barcode       = $('#f-barcode').value.trim();
    const pv = $('#f-price').value.trim();
    m.price = pv === '' ? null : (parseFloat(pv.replace(',', '.')) || null);
    m.wishlist      = $('#f-dest').value === 'wishlist'; // destination choisie

    // Détection de doublon : même titre + même format, DANS LA MÊME collection
    // (biblio ou wishlist). Un film en wishlist n'est pas un doublon d'un film
    // déjà possédé, et inversement.
    if (!isEdit) {
      const norm = (s) => (s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
      const sameFormatDup = State.movies.some(x =>
        !!x.wishlist === !!m.wishlist &&
        norm(x.title) === norm(m.title) && (x.format || 'DVD') === m.format);
      if (sameFormatDup) {
        const lieu = m.wishlist ? 'votre wishlist' : 'votre collection';
        const ok = confirm(`« ${m.title} » est déjà dans ${lieu} en ${m.format}.\n\nVoulez-vous modifier le format (DVD / Blu-ray / 4K) ?\n\nOK = revenir changer le format\nAnnuler = ne pas ajouter`);
        if (ok) {
          toast('Changez le format puis validez');
          return;
        } else {
          closeEditor();
          if (typeof onDone === 'function') { onDone(false); return; }
          go(m.wishlist ? 'wishlist' : 'library');
          return;
        }
      }
    }

    await Store.putMovie(m);
    if (!isEdit) State.movies.push(m);
    if (Cloud.enabled()) Cloud.pushMovie(m).catch(() => {});
    closeEditor();
    toast(isEdit ? 'Film modifié' : (m.wishlist ? 'Ajouté à la wishlist' : 'Film ajouté'));
    if (typeof onDone === 'function') { onDone(true); return; } // import : titre suivant
    isEdit ? renderDetail(m) : go(m.wishlist ? 'wishlist' : 'library');
  };
  $('#edit-cancel').onclick = () => {
    closeEditor();
    if (typeof onDone === 'function') onDone(false); // import : on passe ce titre
  };
}
function field(key, label, val, type = 'text') {
  return `<div class="field"><label>${label}</label>
    <input id="f-${key}" type="${type}" value="${esc(val ?? '')}" /></div>`;
}
function closeEditor() { $('#edit-modal').hidden = true; $('#edit-backdrop').hidden = true; }

/* Aperçu de la jaquette dans l'éditeur */
function renderPosterPreview(url) {
  const box = $('#poster-preview');
  if (!box) return;
  box.innerHTML = url
    ? `<img src="${esc(url)}" alt="jaquette" style="max-width:120px;border-radius:8px;border:1px solid var(--border);margin-bottom:8px" />`
    : '';
}

/* ---- Partage ---- */
async function shareMovie(m) {
  // Texte : infos du film + commentaires écrits
  const lines = [];
  lines.push(`🎬 ${m.title}${m.year ? ' (' + m.year + ')' : ''}`);
  if (m.director) lines.push(`Réalisateur : ${m.director}`);
  if (m.genre)    lines.push(`Genre : ${m.genre}`);
  if (m.format)   lines.push(`Format : ${m.format}`);
  if (m.rating)   lines.push(`Note : ${'★'.repeat(m.rating)}${'☆'.repeat(5 - m.rating)}`);
  if (m.synopsis) lines.push(`\n${m.synopsis}`);
  const texts = (m.textComments || []).map(c => c.text).filter(Boolean);
  if (texts.length) {
    lines.push(`\n📝 Commentaires :`);
    texts.forEach(t => lines.push(`• ${t}`));
  }
  const txt = lines.join('\n');

  // On joint UNIQUEMENT l'affiche (compatible WhatsApp/Messenger).
  let posterFile = null;
  if (m.poster) {
    try {
      const resp = await fetch(m.poster);
      const blob = await resp.blob();
      const ext = (blob.type.split('/')[1] || 'jpg').split('+')[0];
      posterFile = new File([blob], `${m.title}.${ext}`, { type: blob.type });
    } catch (e) { /* affiche non récupérée */ }
  }

  // 1) Tentative : texte + affiche
  if (posterFile && navigator.canShare && navigator.canShare({ files: [posterFile] })) {
    try {
      await navigator.share({ title: m.title, text: txt, files: [posterFile] });
      return;
    } catch (e) {
      if (e.name === 'AbortError') return;
    }
  }
  // 2) Repli : texte seul (+ lien de l'affiche)
  const txtWithLink = m.poster ? `${txt}\n\nAffiche : ${m.poster}` : txt;
  if (navigator.share) {
    try { await navigator.share({ title: m.title, text: txtWithLink }); return; }
    catch (e) { if (e.name === 'AbortError') return; }
  }
  // 3) Repli ultime : presse-papier
  await navigator.clipboard?.writeText(txtWithLink);
  toast('Copié dans le presse-papier');
}

/* ---- Add sheet ---- */
function openSheet()  { $('#add-sheet').hidden = false; $('#sheet-backdrop').hidden = false; }
function closeSheet() { $('#add-sheet').hidden = true;  $('#sheet-backdrop').hidden = true; }

/* ---- Flux d'ajout par scan ---- */
async function startScanFlow() {
  closeSheet();
  Scanner.start(async (ean) => {
    toast('Code détecté : ' + ean + ' — recherche…');
    const film = await MovieAPI.searchByBarcode(ean);
    // Si on a trouvé un vrai film (titre + jaquette), on ouvre la fiche pré-remplie.
    if (film.title && film.poster) {
      toast('Film trouvé ✅');
      openEditor(film);
      return;
    }
    // Sinon : code lu mais film non identifié (limite des bases EAN→DVD).
    // On propose de photographier la jaquette pour l'OCR, sinon saisie manuelle.
    if (confirm(`Code-barres lu (${ean}) mais film non identifié automatiquement.\n\nOK = photographier la jaquette pour reconnaissance.\nAnnuler = saisir le titre à la main.`)) {
      pendingBarcode = ean;       // on gardera le code pour l'attacher au film
      startPhotoFlow();
    } else {
      openEditor(film);           // fiche avec le code pré-rempli
    }
  });
}

// Code-barres en attente d'être rattaché à un film créé via OCR
let pendingBarcode = '';

/* ---- Flux d'ajout par photo de jaquette (OCR) ---- */
function startPhotoFlow() {
  closeSheet();
  // input fichier avec capture caméra arrière sur mobile
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.capture = 'environment';
  input.onchange = async () => {
    const file = input.files && input.files[0];
    if (!file) return;
    const dataURL = await fileToDataURL(file);
    showOcrModal();
    setOcrState('crop', { dataURL });   // étape de recadrage avant OCR
  };
  input.click();
}

function fileToDataURL(file) {
  return new Promise((res) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.readAsDataURL(file);
  });
}

/* ============================================================
   IMPORT D'UNE LISTE DE TITRES (copier-coller)
   L'utilisateur colle une liste (un titre par ligne). Pour chaque
   titre : recherche TMDB -> choix du bon résultat -> éditeur complet
   pré-rempli -> validation -> titre suivant automatiquement.
   ============================================================ */
let importQueue = [];   // titres restants à traiter
let importIndex = 0;    // position courante (pour l'affichage "x sur n")
let importTotal = 0;

function startImportFlow() {
  closeSheet();
  showOcrModal(); // on réutilise la modale OCR
  setOcrState('import-input', {});
}

// Démarre le traitement de la liste collée
function beginImport(text) {
  const titles = text.split('\n')
    .map(t => t.trim())
    .filter(t => t.length >= 1);
  if (!titles.length) { closeOcrModal(); toast('Liste vide'); return; }
  importQueue = titles;
  importIndex = 0;
  importTotal = titles.length;
  processNextImport();
}

// Traite le titre courant de la file
async function processNextImport() {
  if (!importQueue.length) {
    closeOcrModal();
    toast('Import terminé ✅');
    go('library');
    return;
  }
  importIndex = importTotal - importQueue.length + 1;
  const title = importQueue[0];

  showOcrModal();
  setOcrState('import-progress', { title, index: importIndex, total: importTotal });

  const results = await MovieAPI.searchMulti(title);
  if (!results.length) {
    // Rien trouvé : on ouvre l'éditeur avec juste le titre, puis suivant
    closeOcrModal();
    importQueue.shift();
    openEditor({ title }, false, () => processNextImport());
    return;
  }
  // On affiche les résultats à choisir (avec contexte d'import)
  setOcrState('import-choose', { title, results, index: importIndex, total: importTotal });
}

// L'utilisateur a choisi un résultat TMDB pour le titre d'import courant
async function pickImportResult(id) {
  closeOcrModal();
  importQueue.shift();
  let film = { };
  if (id) {
    toast('Chargement de la fiche…');
    film = await MovieAPI.getDetails(id) || {};
  }
  // Éditeur complet pré-rempli ; à la validation OU annulation -> titre suivant
  openEditor({ ...film }, false, () => processNextImport());
}

// L'utilisateur saute le titre courant
function skipImport() {
  importQueue.shift();
  processNextImport();
}

/* Recadre l'image sur la zone choisie (en %) et renvoie un dataURL */
function cropImage(dataURL, cropPct) {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload = () => {
      const sx = img.width  * cropPct.x;
      const sy = img.height * cropPct.y;
      const sw = img.width  * cropPct.w;
      const sh = img.height * cropPct.h;
      const canvas = document.createElement('canvas');
      canvas.width = sw; canvas.height = sh;
      canvas.getContext('2d').drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
      res(canvas.toDataURL('image/png'));
    };
    img.onerror = () => rej(new Error('Image illisible'));
    img.src = dataURL;
  });
}

async function runOCR(dataURL) {
  showOcrModal();
  setOcrState('progress', { pct: 0 });
  try {
    const { candidates, rawText } = await OCR.recognize(dataURL, (p) => {
      setOcrState('progress', { pct: Math.round(p * 100) });
    });
    if (!candidates.length) {
      setOcrState('empty', { rawText });
    } else {
      setOcrState('choose', { candidates, dataURL });
    }
  } catch (e) {
    toast(e.message || 'OCR échoué');
    closeOcrModal();
    openEditor({}); // repli saisie manuelle
  }
}

/* Cherche le titre sur TMDB. Si plusieurs résultats, on les affiche
   pour que l'utilisateur choisisse le bon (ex: Casino vs Casino Royale). */
async function ocrSearchTitle(title) {
  toast('Recherche TMDB : ' + title + '…');
  const results = await MovieAPI.searchMulti(title);
  if (!results.length) {
    closeOcrModal();
    const barcode = pendingBarcode; pendingBarcode = '';
    toast('Aucun résultat TMDB — complétez à la main');
    openEditor({ ...MovieAPI.blankFromBarcode(barcode, title) });
    return;
  }
  // Un seul résultat : on prend direct. Plusieurs : on laisse choisir.
  if (results.length === 1) {
    pickTmdbResult(results[0].id);
  } else {
    setOcrState('results', { results });
  }
}

/* L'utilisateur a choisi un film précis dans la liste TMDB */
async function pickTmdbResult(id) {
  closeOcrModal();
  toast('Chargement de la fiche…');
  const barcode = pendingBarcode; pendingBarcode = '';
  const film = await MovieAPI.getDetails(id);
  if (film) {
    toast('Film trouvé ✅');
    openEditor({ ...film, barcode });
  } else {
    toast('Erreur — saisie manuelle');
    openEditor({ ...MovieAPI.blankFromBarcode(barcode, '') });
  }
}

/* --- Modale OCR (réutilise le backdrop d'édition) --- */
function showOcrModal() {
  let modal = $('#ocr-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'ocr-modal';
    modal.className = 'modal';
    document.body.appendChild(modal);
  }
  modal.hidden = false;
  $('#edit-backdrop').hidden = false;
}
function closeOcrModal() {
  const modal = $('#ocr-modal');
  if (modal) modal.hidden = true;
  $('#edit-backdrop').hidden = true;
}
function setOcrState(state, data = {}) {
  const modal = $('#ocr-modal');
  if (!modal) return;
  if (state === 'crop') {
    modal.innerHTML = `
      <div class="modal-head">
        <button class="btn-ghost" id="ocr-cancel" style="width:auto">Annuler</button>
        <strong>Cadrez le titre</strong>
        <button class="btn-link" id="crop-go">Analyser</button>
      </div>
      <div class="modal-body" style="padding:12px">
        <p class="muted small">Déplacez et redimensionnez le cadre sur le <b>titre</b> du film, puis « Analyser ».</p>
        <div id="crop-stage" style="position:relative;touch-action:none;user-select:none;margin-top:10px">
          <img id="crop-img" src="${data.dataURL}" style="width:100%;display:block;border-radius:8px" />
          <div id="crop-box" style="position:absolute;border:2px solid var(--accent);box-shadow:0 0 0 9999px rgba(0,0,0,.45);left:10%;top:35%;width:80%;height:18%;cursor:move"></div>
        </div>
        <button class="btn-ghost" id="crop-full" style="margin-top:12px">Analyser toute l'image</button>
      </div>`;
    setupCrop(data.dataURL);
    $('#ocr-cancel').addEventListener('click', closeOcrModal);
  } else if (state === 'import-input') {
    modal.innerHTML = `
      <div class="modal-head">
        <button class="btn-ghost" id="ocr-cancel" style="width:auto">Annuler</button>
        <strong>Importer une liste</strong><span></span>
      </div>
      <div class="modal-body">
        <p class="muted small">Collez votre liste de films, <b>un titre par ligne</b>. Vous validerez chaque film un par un.</p>
        <div class="field" style="margin-top:12px">
          <textarea id="import-textarea" rows="10" placeholder="Casino&#10;Le Parrain&#10;Heat&#10;Pulp Fiction&#10;…"></textarea>
        </div>
        <button class="btn-primary" id="import-start-btn">Importer ces films</button>
      </div>`;
    $('#import-start-btn').addEventListener('click', () => {
      const txt = $('#import-textarea').value;
      if (txt.trim()) beginImport(txt);
    });
    $('#ocr-cancel').addEventListener('click', closeOcrModal);
  } else if (state === 'import-progress') {
    modal.innerHTML = `
      <div class="modal-head">
        <span></span><strong>Import ${data.index}/${data.total}</strong><span></span>
      </div>
      <div class="modal-body" style="text-align:center;padding-top:40px">
        <div class="ocr-spinner">🔍</div>
        <p class="muted">Recherche : « ${esc(data.title)} »…</p>
      </div>`;
  } else if (state === 'import-choose') {
    modal.innerHTML = `
      <div class="modal-head">
        <button class="btn-ghost" id="ocr-cancel" style="width:auto">Arrêter</button>
        <strong>${data.index}/${data.total} · ${esc(data.title)}</strong>
        <button class="btn-link" id="import-skip">Passer</button>
      </div>
      <div class="modal-body">
        <p class="muted small">Choisissez le bon film (ou « Passer ») :</p>
        <div class="tmdb-results">
          ${data.results.map(r => `
            <button class="tmdb-result" data-id="${r.id}">
              <div class="tmdb-poster" style="${r.poster ? `background-image:url('${r.poster}')` : ''}">${r.poster ? '' : '🎬'}</div>
              <div class="tmdb-info">
                <div class="tmdb-title">${esc(r.title)}</div>
                <div class="tmdb-year">${r.year || '—'}</div>
              </div>
            </button>`).join('')}
        </div>
        <button class="btn-ghost" id="import-manual" style="margin-top:10px">Aucun ne correspond — saisir à la main</button>
      </div>`;
    $$('.tmdb-result', modal).forEach(b =>
      b.addEventListener('click', () => pickImportResult(Number(b.dataset.id))));
    $('#import-skip').addEventListener('click', skipImport);
    $('#import-manual').addEventListener('click', () => pickImportResult(null));
    $('#ocr-cancel').addEventListener('click', () => {
      importQueue = []; closeOcrModal(); toast('Import arrêté'); go('library');
    });
  } else if (state === 'progress') {
    modal.innerHTML = `
      <div class="modal-head">
        <span></span><strong>Lecture de la jaquette…</strong>
        <button class="btn-ghost" id="ocr-cancel" style="width:auto">Annuler</button>
      </div>
      <div class="modal-body" style="text-align:center;padding-top:40px">
        <div class="ocr-spinner">🔍</div>
        <p class="muted">Analyse du texte… ${data.pct || 0}%</p>
        <div class="ocr-bar"><div class="ocr-bar-fill" style="width:${data.pct||0}%"></div></div>
        <p class="muted small" style="margin-top:20px">Le moteur OCR (~2 Mo) se charge au premier usage.</p>
      </div>`;
  } else if (state === 'results') {
    modal.innerHTML = `
      <div class="modal-head">
        <button class="btn-ghost" id="ocr-cancel" style="width:auto">Annuler</button>
        <strong>Quel film ?</strong>
        <button class="btn-link" id="ocr-manual2">Manuel</button>
      </div>
      <div class="modal-body">
        <p class="muted small">Plusieurs films correspondent. Touchez le bon :</p>
        <div class="tmdb-results">
          ${data.results.map(r => `
            <button class="tmdb-result" data-id="${r.id}">
              <div class="tmdb-poster" style="${r.poster ? `background-image:url('${r.poster}')` : ''}">${r.poster ? '' : '🎬'}</div>
              <div class="tmdb-info">
                <div class="tmdb-title">${esc(r.title)}</div>
                <div class="tmdb-year">${r.year || '—'}</div>
              </div>
            </button>`).join('')}
        </div>
      </div>`;
    $$('.tmdb-result', modal).forEach(b =>
      b.addEventListener('click', () => pickTmdbResult(Number(b.dataset.id))));
    $('#ocr-manual2').addEventListener('click', () => { closeOcrModal(); openEditor({}); });
  } else if (state === 'choose') {
    modal.innerHTML = `
      <div class="modal-head">
        <button class="btn-ghost" id="ocr-cancel" style="width:auto">Annuler</button>
        <strong>Quel est le titre ?</strong>
        <button class="btn-link" id="ocr-manual2">Manuel</button>
      </div>
      <div class="modal-body">
        <p class="muted small">Texte détecté sur la jaquette. Touchez le titre du film :</p>
        <div class="ocr-candidates">
          ${data.candidates.map((c, i) =>
            `<button class="ocr-cand" data-i="${i}">${esc(c)}</button>`).join('')}
        </div>
        <div class="field" style="margin-top:16px">
          <label>Ou corrigez / saisissez le titre</label>
          <input id="ocr-edit-title" type="text" placeholder="Titre du film" value="${esc(data.candidates[0] || '')}" />
        </div>
        <button class="btn-primary" id="ocr-search-btn">Rechercher ce film</button>
      </div>`;
    $$('.ocr-cand', modal).forEach(b =>
      b.addEventListener('click', () => {
        // Clic sur un candidat : on remplit le champ ET on lance la recherche
        const t = data.candidates[+b.dataset.i];
        const input = $('#ocr-edit-title'); if (input) input.value = t;
        ocrSearchTitle(t);
      }));
    $('#ocr-search-btn').addEventListener('click', () => {
      const v = $('#ocr-edit-title').value.trim();
      if (v) ocrSearchTitle(v);
    });
    $('#ocr-manual2').addEventListener('click', () => { closeOcrModal(); openEditor({}); });
  } else if (state === 'empty') {
    modal.innerHTML = `
      <div class="modal-head">
        <button class="btn-ghost" id="ocr-cancel" style="width:auto">Annuler</button>
        <strong>Aucun titre lisible</strong><span></span>
      </div>
      <div class="modal-body">
        <p class="muted">Le texte n'a pas pu être lu de façon fiable. Vous pouvez saisir le titre manuellement.</p>
        <div class="field" style="margin-top:12px">
          <input id="ocr-edit-title" type="text" placeholder="Titre du film" />
        </div>
        <button class="btn-primary" id="ocr-search-btn">Rechercher</button>
        <button class="btn-ghost" id="ocr-manual2" style="margin-top:8px">Saisie complète manuelle</button>
      </div>`;
    $('#ocr-search-btn').addEventListener('click', () => {
      const v = $('#ocr-edit-title').value.trim();
      if (v) ocrSearchTitle(v);
    });
    $('#ocr-manual2').addEventListener('click', () => { closeOcrModal(); openEditor({}); });
  }
  const cancel = $('#ocr-cancel');
  if (cancel) cancel.addEventListener('click', closeOcrModal);
}

/* Gère le cadre de recadrage (déplacement + redimensionnement tactile)
   et les boutons « Analyser » (zone) / « Analyser toute l'image ». */
function setupCrop(dataURL) {
  const stage = $('#crop-stage'), box = $('#crop-box');
  if (!stage || !box) return;

  let mode = null, startX = 0, startY = 0, orig = {};
  const rect = () => stage.getBoundingClientRect();
  const pct = (px, total) => Math.max(0, Math.min(1, px / total));

  // Zone de redimensionnement : coin bas-droit (20px). Sinon déplacement.
  function pointerDown(e) {
    const t = e.touches ? e.touches[0] : e;
    const b = box.getBoundingClientRect();
    startX = t.clientX; startY = t.clientY;
    orig = { left: box.offsetLeft, top: box.offsetTop, w: box.offsetWidth, h: box.offsetHeight };
    const nearCorner = (t.clientX > b.right - 28) && (t.clientY > b.bottom - 28);
    mode = nearCorner ? 'resize' : 'move';
    e.preventDefault();
  }
  function pointerMove(e) {
    if (!mode) return;
    const t = e.touches ? e.touches[0] : e;
    const r = rect();
    const dx = t.clientX - startX, dy = t.clientY - startY;
    if (mode === 'move') {
      box.style.left = Math.max(0, Math.min(r.width - box.offsetWidth, orig.left + dx)) + 'px';
      box.style.top  = Math.max(0, Math.min(r.height - box.offsetHeight, orig.top + dy)) + 'px';
    } else {
      box.style.width  = Math.max(40, Math.min(r.width - box.offsetLeft, orig.w + dx)) + 'px';
      box.style.height = Math.max(30, Math.min(r.height - box.offsetTop, orig.h + dy)) + 'px';
    }
    e.preventDefault();
  }
  function pointerUp() { mode = null; }

  box.addEventListener('mousedown', pointerDown);
  box.addEventListener('touchstart', pointerDown, { passive: false });
  window.addEventListener('mousemove', pointerMove);
  window.addEventListener('touchmove', pointerMove, { passive: false });
  window.addEventListener('mouseup', pointerUp);
  window.addEventListener('touchend', pointerUp);

  // Analyser la zone recadrée
  $('#crop-go').addEventListener('click', async () => {
    const r = rect();
    const cropPct = {
      x: pct(box.offsetLeft, r.width),
      y: pct(box.offsetTop, r.height),
      w: pct(box.offsetWidth, r.width),
      h: pct(box.offsetHeight, r.height),
    };
    try {
      const cropped = await cropImage(dataURL, cropPct);
      runOCR(cropped);
    } catch (e) { toast('Erreur recadrage'); runOCR(dataURL); }
  });
  // Analyser toute l'image
  $('#crop-full').addEventListener('click', () => runOCR(dataURL));
}

/* ---- Filtres (prompt simple, pas de lib) ---- */
function openFilters() {
  // Tous les genres possibles (mêmes que ceux proposés à la création d'une fiche)
  const genres = GENRES;

  showOcrModal();
  const modal = $('#ocr-modal');
  modal.innerHTML = `
    <div class="modal-head">
      <button class="btn-ghost" id="ocr-cancel" style="width:auto">Fermer</button>
      <strong>Filtrer par genre</strong><span></span>
    </div>
    <div class="modal-body">
      <div class="genre-list">
        <button class="genre-item ${!State.filters.genre ? 'active' : ''}" data-g="">Tous les genres</button>
        ${genres.map(g => `
          <button class="genre-item ${State.filters.genre === g ? 'active' : ''}" data-g="${esc(g)}">${esc(g)}</button>
        `).join('')}
      </div>
    </div>`;
  $$('.genre-item', modal).forEach(b => b.addEventListener('click', () => {
    const g = b.dataset.g;
    if (g) State.filters.genre = g; else delete State.filters.genre;
    closeOcrModal();
    renderLibrary();
  }));
  $('#ocr-cancel').addEventListener('click', closeOcrModal);
}

/* ---- Import / Export ---- */
async function exportJSON() {
  const data = JSON.stringify({ version: 1, exportedAt: Date.now(), movies: State.movies }, null, 2);
  const blob = new Blob([data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `dvdtheque-${new Date().toISOString().slice(0,10)}.json`;
  a.click(); URL.revokeObjectURL(url);
}

/* Charge jsPDF à la demande (CDN) */
function loadJsPDF() {
  if (window.jspdf && window.jspdf.jsPDF) return Promise.resolve();
  return new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js';
    s.onload = res;
    s.onerror = () => rej(new Error('Chargement jsPDF impossible (réseau ?)'));
    document.head.appendChild(s);
  });
}

/* Télécharge une image et la convertit en dataURL (pour l'intégrer au PDF).
   Renvoie null si échec (affiche manquante / réseau). */
function imageToDataURL(url) {
  return new Promise((res) => {
    if (!url) return res(null);
    fetch(url)
      .then(r => r.blob())
      .then(blob => {
        const r = new FileReader();
        r.onload = () => res(r.result);
        r.onerror = () => res(null);
        r.readAsDataURL(blob);
      })
      .catch(() => res(null));
  });
}

/* Exporte la collection visible (respecte le filtre actif) en PDF,
   sous forme de grille de vignettes : affiche + titre + réalisateur
   + année + genre + format. */
async function exportPDF(mode = 'library', withPrice = false) {
  const isWish = mode === 'wishlist';
  const movies = isWish
    ? State.movies.filter(m => m.wishlist)
    : visibleMovies();
  if (!movies.length) { toast(isWish ? 'Wishlist vide' : 'Aucun film à exporter'); return; }

  toast('Génération du PDF…');
  try {
    await loadJsPDF();
  } catch (e) { toast(e.message); return; }

  const { jsPDF } = window.jspdf;
  const pdf = new jsPDF({ unit: 'mm', format: 'a4' });
  const pageW = 210, pageH = 297;
  const margin = 12;
  const cols = 3;
  const gap = 8;
  const cellW = (pageW - margin * 2 - gap * (cols - 1)) / cols; // largeur d'une vignette
  const posterH = cellW * 1.4;      // ratio affiche ~ 1:1.4
  const textH = 20;                 // hauteur réservée au texte sous l'affiche
  const cellH = posterH + textH;
  const headerH = 22;  // hauteur réservée à l'en-tête (titre + 2 lignes)
  const rowsPerPage = Math.floor((pageH - margin * 2 - headerH) / (cellH + gap));

  // Titre du document
  pdf.setFontSize(18);
  pdf.text(isWish ? 'Ma Wishlist' : 'Ma DVDthèque', margin, margin + 4);
  pdf.setFontSize(10);
  pdf.setTextColor(120);
  // Portée
  let portee;
  if (isWish) {
    portee = 'Films recherchés';
  } else {
    portee = State.formatFilter ? `Format : ${State.formatFilter}` : 'Collection complète';
    if (State.filters.genre) portee += ` · Genre : ${State.filters.genre}`;
  }
  pdf.text(`${portee} — ${movies.length} film(s)`, margin, margin + 10);
  // Date de création du PDF
  const dateStr = new Date().toLocaleDateString('fr-FR', {
    day: '2-digit', month: 'long', year: 'numeric',
  });
  pdf.text(`Généré le ${dateStr}`, margin, margin + 15);
  pdf.setTextColor(0);

  let col = 0, row = 0;
  const startY = margin + headerH;

  for (let i = 0; i < movies.length; i++) {
    const m = movies[i];
    const x = margin + col * (cellW + gap);
    const y = startY + row * (cellH + gap);

    // Affiche (ou cadre avec initiale si absente)
    const img = await imageToDataURL(m.poster);
    if (img) {
      try { pdf.addImage(img, 'JPEG', x, y, cellW, posterH); }
      catch (e) {
        pdf.setDrawColor(200); pdf.rect(x, y, cellW, posterH);
      }
    } else {
      pdf.setFillColor(235); pdf.rect(x, y, cellW, posterH, 'F');
      pdf.setFontSize(22); pdf.setTextColor(150);
      pdf.text((m.title || '?').charAt(0).toUpperCase(), x + cellW / 2, y + posterH / 2, { align: 'center', baseline: 'middle' });
      pdf.setTextColor(0);
    }

    // Texte sous l'affiche
    let ty = y + posterH + 4;
    pdf.setFontSize(8.5); pdf.setTextColor(0);
    const title = pdf.splitTextToSize(m.title || 'Sans titre', cellW);
    pdf.text(title.slice(0, 2), x, ty); // max 2 lignes de titre
    ty += title.length > 1 ? 7 : 4;
    pdf.setFontSize(7); pdf.setTextColor(90);
    const meta = [m.director, m.year, m.genre, m.format].filter(Boolean).join(' · ');
    const metaLines = pdf.splitTextToSize(meta, cellW);
    pdf.text(metaLines.slice(0, 2), x, ty);
    // Prix sous la meta (si demandé et renseigné)
    if (withPrice && m.price != null && m.price !== '') {
      ty += (metaLines.length > 1 ? 6 : 3.5);
      pdf.setFontSize(8); pdf.setTextColor(0);
      pdf.text(fmtPrice(m.price), x, ty);
    }
    pdf.setTextColor(0);

    // Avance dans la grille
    col++;
    if (col >= cols) { col = 0; row++; }
    if (row >= rowsPerPage && i < movies.length - 1) {
      pdf.addPage(); row = 0; col = 0;
    }
  }

  // Total de la collection (si prix demandés)
  if (withPrice) {
    const withP = movies.filter(m => m.price != null && m.price !== '');
    if (withP.length) {
      const total = withP.reduce((s, m) => s + Number(m.price), 0);
      // Position sous la dernière rangée utilisée
      let totalY = startY + (col === 0 ? row : row + 1) * (cellH + gap) + 4;
      if (totalY > pageH - margin - 10) { pdf.addPage(); totalY = margin + 10; }
      pdf.setFontSize(12); pdf.setTextColor(0);
      pdf.text(`Valeur totale de la collection : ${fmtPrice(total)}`, margin, totalY);
      pdf.setFontSize(8); pdf.setTextColor(120);
      pdf.text(`(${withP.length} film(s) avec prix sur ${movies.length})`, margin, totalY + 5);
      pdf.setTextColor(0);
    }
  }

  const fname = `${isWish ? 'wishlist' : 'ma-dvdtheque'}-${new Date().toISOString().slice(0,10)}.pdf`;
  // Sur mobile, ouvrir le partage natif si possible, sinon télécharger
  const blob = pdf.output('blob');
  const file = new File([blob], fname, { type: 'application/pdf' });
  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    try { await navigator.share({ files: [file], title: isWish ? 'Ma Wishlist' : 'Ma DVDthèque' }); return; }
    catch (e) { if (e.name === 'AbortError') return; }
  }
  // Repli : téléchargement
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = fname; a.click();
  URL.revokeObjectURL(url);
  toast('PDF généré ✅');
}
function importJSON() {
  const input = document.createElement('input');
  input.type = 'file'; input.accept = 'application/json';
  input.onchange = async () => {
    const file = input.files[0]; if (!file) return;
    try {
      const j = JSON.parse(await file.text());
      const incoming = j.movies || [];
      for (const m of incoming) { m.id = m.id || uid(); await Store.putMovie(m); }
      State.movies = await Store.allMovies();
      toast(`${incoming.length} film(s) importé(s)`); go('library');
    } catch (e) { toast('Fichier invalide'); }
  };
  input.click();
}

/* ---- Thème ---- */
async function toggleTheme() {
  State.settings.theme = State.settings.theme === 'dark' ? 'light' : 'dark';
  applyTheme(); await Store.setKV('settings', State.settings); renderProfile();
}
function applyTheme() {
  document.documentElement.setAttribute('data-theme', State.settings.theme);
}

/* ---- Clé API ---- */
async function configureAPI() {
  const provider = prompt('Fournisseur API ("tmdb" ou "omdb") :', State.settings.apiProvider) || 'tmdb';
  const key = prompt(`Clé API ${provider.toUpperCase()} :`, State.settings.apiKey || '');
  if (key !== null) {
    State.settings.apiProvider = provider.trim().toLowerCase();
    State.settings.apiKey = key.trim();
    await Store.setKV('settings', State.settings);
    toast('Réglages API enregistrés');
  }
}

/* ============================================================
   7. BOOTSTRAP
   ============================================================ */
async function boot() {
  await Store.init();

  const saved = await Store.getKV('settings');
  if (saved) State.settings = { ...State.settings, ...saved };
  applyTheme();

  bindEvents();
  bindLogin();

  // Service worker : zéro cache + auto-update.
  // Quand un nouveau service worker prend le contrôle, on recharge
  // la page une seule fois pour servir la dernière version (sans
  // que l'utilisateur ait à vider quoi que ce soit).
  if ('serviceWorker' in navigator) {
    let refreshing = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (refreshing) return;
      refreshing = true;
      window.location.reload();
    });
    navigator.serviceWorker.register('./sw.js').then((reg) => {
      reg.update(); // cherche une nouvelle version immédiatement
      // Vérifie aussi à chaque retour sur l'app (onglet réactivé)
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') reg.update();
      });
    }).catch(() => {});
  }

  if (Cloud.configured()) {
    // Mode connecté : on affiche l'écran de login tant que Firebase
    // n'a pas confirmé une session. onAuthChanged gère l'affichage.
    showLogin(true);
    try {
      await Cloud.init(onAuthChanged);
    } catch (e) {
      console.warn('Cloud init:', e);
      // En cas d'échec d'init, on bascule en mode local pour ne pas bloquer
      showLogin(false);
      State.movies = await Store.allMovies();
      go('library');
    }
  } else {
    // Pas de config Firebase : mode 100% local, pas de mur de connexion
    showLogin(false);
    State.movies = await Store.allMovies();
    go('library');
  }
}

/* Affiche / masque l'écran de connexion plein écran */
function showLogin(show) {
  const screen = $('#login-screen'), app = $('#app');
  if (screen) screen.hidden = !show;
  if (app) app.style.display = show ? 'none' : '';
}

function bindLogin() {
  const btn = $('#login-google-btn');
  if (btn) btn.addEventListener('click', async () => {
    const err = $('#login-error');
    if (err) err.hidden = true;
    try {
      await Cloud.signInGoogle();
      // onAuthChanged prend le relais
    } catch (e) {
      console.warn(e);
      if (err) { err.textContent = 'Connexion échouée. Réessayez.'; err.hidden = false; }
    }
  });
}

/* Appelé à chaque changement d'état de connexion Google. */
let _firstAuth = true;
async function onAuthChanged(user) {
  if (user) {
    // Connecté : on masque le login, on charge la liste du compte
    showLogin(false);
    State.movies = await Store.allMovies();
    go('library');
    renderProfile();
    try {
      await syncCloud();
      renderLibrary();
    } catch (e) { console.warn('sync après login:', e); }
  } else {
    // Pas (ou plus) connecté : on vide l'affichage local et on montre le login
    if (!_firstAuth) {
      State.movies = [];
      await Store.clearMovies();
    }
    showLogin(true);
  }
  _firstAuth = false;
}

/* Fusion locale <-> distante. Stratégie simple : union par id, le
   plus récemment modifié gagne (champ addedAt/at faute de updatedAt).
   Pour un test c'est suffisant ; un vrai merge viendra côté Flutter. */
async function syncCloud() {
  if (!Cloud.enabled()) return;
  const remote = await Cloud.pullAll();
  const localById = new Map(State.movies.map(m => [m.id, m]));
  const remoteById = new Map(remote.map(m => [m.id, m]));

  // Distant -> local (ajoute ce qui manque localement)
  for (const r of remote) {
    if (!localById.has(r.id)) {
      await Store.putMovie(r);
      localById.set(r.id, r);
    }
  }
  // Local -> distant (pousse ce qui manque à distance)
  for (const l of State.movies) {
    if (!remoteById.has(l.id)) {
      await Cloud.pushMovie(l).catch(() => {});
    }
  }
  State.movies = await Store.allMovies();
}

/* Connexion / déconnexion Google depuis le profil */
async function cloudSignIn() {
  if (!Cloud.configured()) {
    alert('Sync cloud non configurée (FIREBASE_CONFIG manquant dans app.js).');
    return;
  }
  try {
    toast('Connexion Google…');
    await Cloud.signInGoogle();
    // onAuthChanged fait le reste (sync + affichage)
  } catch (e) {
    console.warn(e);
    toast('Connexion annulée ou échouée');
  }
}

async function cloudSignOut() {
  if (confirm('Se déconnecter ? Ta liste reste sauvegardée dans ton compte Google.')) {
    try { await Cloud.signOut(); } catch (e) { toast('Erreur déconnexion'); }
  }
}

function bindEvents() {
  // Tabs
  $$('.tab[data-go]').forEach(t => t.addEventListener('click', () => go(t.dataset.go)));
  $('#add-tab').addEventListener('click', openSheet);

  // Topbar
  $('#back-btn').addEventListener('click', () => {
    const m = State.movies.find(x => x.id === State.currentId);
    go(m && m.wishlist ? 'wishlist' : 'library');
  });
  $('#search-toggle').addEventListener('click', () => {
    const sb = $('#searchbar'); sb.hidden = !sb.hidden;
    if (!sb.hidden) $('#search-input').focus();
  });
  $('#search-input').addEventListener('input', (e) => {
    State.search = e.target.value; renderLibrary();
  });

  // Toolbar
  $$('#layout-seg button').forEach(b => b.addEventListener('click', () => {
    State.layout = b.dataset.layout;
    $$('#layout-seg button').forEach(x => x.classList.toggle('active', x === b));
    renderLibrary();
  }));
  $$('#format-seg button').forEach(b => b.addEventListener('click', () => {
    State.formatFilter = b.dataset.fmt;
    $$('#format-seg button').forEach(x => x.classList.toggle('active', x === b));
    renderLibrary();
  }));
  $('#sort-select').addEventListener('change', (e) => { State.sort = e.target.value; renderLibrary(); });
  $('#filter-btn').addEventListener('click', openFilters);

  // Add sheet
  $('#sheet-backdrop').addEventListener('click', closeSheet);
  $('#act-cancel').addEventListener('click', closeSheet);
  $('#act-manual').addEventListener('click', () => { closeSheet(); openEditor({}); });
  $('#act-photo').addEventListener('click', startPhotoFlow);
  $('#act-import').addEventListener('click', startImportFlow);
  $('[data-action="add"]')?.addEventListener('click', openSheet);

  // Scanner
  $('#scanner-close').addEventListener('click', () => Scanner.stop());

  // Edit backdrop
  $('#edit-backdrop').addEventListener('click', closeEditor);

  // Random
  $('#random-go').addEventListener('click', spinRandom);
  $('#random-open').addEventListener('click', () => randomPick && openDetail(randomPick.id));

  // Profile
  $('#set-pdf').addEventListener('click', () => {
    const withPrice = confirm("Inclure les prix d'achat et le total dans le PDF ?\n\nOK = avec les prix\nAnnuler = sans les prix");
    exportPDF('library', withPrice);
  });
  $('#set-pdf-wish').addEventListener('click', () => exportPDF('wishlist', false));
  $('#set-theme').addEventListener('click', toggleTheme);
  $('#set-cloud').addEventListener('click', () => {
    if (Cloud.user && Cloud.user()) cloudSignOut();
    else cloudSignIn();
  });
  $('#set-wipe').addEventListener('click', async () => {
    if (!confirm('Vider toute la collection ? Action irréversible.')) return;
    await Store.clearMovies(); State.movies = []; toast('Collection vidée'); go('library');
  });
}

/* ---- Données d'exemple ---- */
async function seedDemo() {
  const demo = [
    { title: 'Le Voyage', year: '2021', genre: 'Drame', format: 'Blu-ray', rating: 4,
      director: 'A. Martin', actors: 'J. Dupont, M. Leroy', duration: 118,
      synopsis: 'Un road-trip introspectif à travers les Alpes.' },
    { title: 'Nébuleuse', year: '2019', genre: 'Science-Fiction', format: '4K', rating: 5,
      director: 'C. Nolan', actors: 'E. Stone', duration: 142,
      synopsis: 'Une expédition spatiale aux confins du système solaire.' },
    { title: 'Comédie de Quartier', year: '2015', genre: 'Comédie', format: 'DVD', rating: 3,
      director: 'P. Durand', actors: 'L. Bernard', duration: 95, synopsis: '' },
  ];
  for (const d of demo) {
    const m = { id: uid(), addedAt: Date.now() - Math.random()*1e9,
      audio: [], textComments: [], poster: '', ...d };
    await Store.putMovie(m);
  }
  State.movies = await Store.allMovies();
}

document.addEventListener('DOMContentLoaded', boot);
